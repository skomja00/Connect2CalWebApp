﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using Utilities;

namespace CalendarSOAPWebService
{
    /// <summary>
    /// Account class related WebServices 
    /// </summary>
    [WebService(Namespace = "http://temple.edu/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Account : System.Web.Services.WebService
    {
        DBConnect objDB = new DBConnect();

        [WebMethod]
        public DataSet LogIn(string theLoginEmail, Byte[] theLoginPass)
        {
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.CommandType = CommandType.StoredProcedure;
            objSqlCommand.CommandText = "TP_Account_Login_SP";

            SqlParameter userName = new SqlParameter("@CreatedEmailAddress", theLoginEmail);
            userName.Direction = ParameterDirection.Input;
            userName.SqlDbType = SqlDbType.VarChar;
            userName.Size = 254;
            objSqlCommand.Parameters.Add(userName);

            SqlParameter accountPassword = new SqlParameter("@AccountPassword", theLoginPass);
            accountPassword.Direction = ParameterDirection.Input;
            accountPassword.SqlDbType = SqlDbType.VarBinary;
            //accountPassword.Size = 32;
            objSqlCommand.Parameters.Add(accountPassword);

            // Execute stored procedure to login. 
            return objDB.GetDataSetUsingCmdObj(objSqlCommand); 
        }
        /// <summary>
        /// Check the given responses to the Security Question match the database.
        /// Return the number of matching responses.
        /// </summary>
        /// <param name="theCreatedEmailAddress"></param>
        /// <param name="theResponseCity"></param>
        /// <param name="theResponsePhone"></param>
        /// <param name="theResponseSchool"></param>
        /// <returns>int Number of matching responses</returns>
        [WebMethod]
        public int SecurityQuestions(string theCreatedEmailAddress,
                                    string theResponseCity,
                                    string theResponsePhone,
                                    string theResponseSchool)
        {
            DBConnect objDB = new DBConnect();
            SqlCommand objSqlCmd = new SqlCommand();

            objSqlCmd.CommandText = "TP_Account_Security_Questions_SP";
            objSqlCmd.CommandType = CommandType.StoredProcedure;

            SqlParameter emailParm = new SqlParameter("@CreatedEmailAddress", theCreatedEmailAddress);
            emailParm.Direction = ParameterDirection.Input;
            emailParm.SqlDbType = SqlDbType.VarChar;
            emailParm.Size = 254;
            objSqlCmd.Parameters.Add(emailParm);

            SqlParameter cityParm = new SqlParameter("@ResponseCity", theResponseCity);
            cityParm.Direction = ParameterDirection.Input;
            cityParm.SqlDbType = SqlDbType.VarChar;
            cityParm.Size = 254;
            objSqlCmd.Parameters.Add(cityParm);

            SqlParameter phoneParm = new SqlParameter("@ResponsePhone", theResponsePhone);
            phoneParm.Direction = ParameterDirection.Input;
            phoneParm.SqlDbType = SqlDbType.VarChar;
            phoneParm.Size = 254;
            objSqlCmd.Parameters.Add(phoneParm);

            SqlParameter schoolParm = new SqlParameter("@ResponseSchool", theResponseSchool);
            schoolParm.Direction = ParameterDirection.Input;
            schoolParm.SqlDbType = SqlDbType.VarChar;
            schoolParm.Size = 254;
            objSqlCmd.Parameters.Add(schoolParm);

            DataSet objDS = objDB.GetDataSetUsingCmdObj(objSqlCmd);

            int numOfCorrectResponses = Convert.ToInt32(objDS.Tables[0].Rows[0].ItemArray[0]);

            return numOfCorrectResponses;
        }
        /// <summary>
        /// Execute the TP_Account_Update_Password_SP stored procedure to update the AccountPassword
        /// </summary>
        /// <param name="theCreatedEmailAddress"></param>
        /// <param name="thePassword"></param>
        /// <returns>Integer number of rows affected by the update, or -1 for an exception</returns>
        [WebMethod]
        public int UpdatePassword(string theCreatedEmailAddress, Byte[] thePassword)
        {
            DBConnect objDB = new DBConnect();
            SqlCommand objSqlCmd = new SqlCommand();

            objSqlCmd.CommandText = "TP_Account_Update_Password_SP";
            objSqlCmd.CommandType = CommandType.StoredProcedure;

            SqlParameter emailParm = new SqlParameter("@CreatedEmailAddress", theCreatedEmailAddress);
            emailParm.Direction = ParameterDirection.Input;
            emailParm.SqlDbType = SqlDbType.VarChar;
            emailParm.Size = 254;
            objSqlCmd.Parameters.Add(emailParm);

            SqlParameter passwordParm = new SqlParameter("@AccountPassword", thePassword);
            passwordParm.Direction = ParameterDirection.Input;
            passwordParm.SqlDbType = SqlDbType.VarBinary;
            //passwordParm.Size = 32;
            objSqlCmd.Parameters.Add(passwordParm);

            int returnValue = objDB.DoUpdateUsingCmdObj(objSqlCmd);

            return returnValue;
        }
    }
}
