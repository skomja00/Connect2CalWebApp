﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace CalendarClassLibrary.Model
{
    public class SecurityQuestion
    {

        private int seurtiyQuestionId;
        private int accountId;
        private String question;
        private String questionType;
        private String response;
        private DateTime dateTimeStamp;

        public SecurityQuestion()
        {

        }

        public Boolean AddSecurityQuestion(string email)
        {
            string data = "";
            //serialize the object into a json string.
            JavaScriptSerializer js = new JavaScriptSerializer();
            string jsonstring = js.Serialize(this);

            try
            {
                WebRequest request = WebRequest.Create("http://cis-iis2.temple.edu/spring2021/cis3342_tun49199/TermProject/api/SecurityQuestion/AddSecurityQuestion/email=" + email);
                //WebRequest request = WebRequest.Create("https://localhost:44380/api/SecurityQuestion/AddSecurityQuestion/email=" + email);
                request.Method = "POST";
                request.ContentLength = jsonstring.Length;
                request.ContentType = "application/json";

                // write the json data to the web request
                StreamWriter writer = new StreamWriter(request.GetRequestStream());
                writer.Write(jsonstring);
                writer.Flush();
                writer.Close();

                // read the data from the web response, which requires working with streams.
                WebResponse response = request.GetResponse();
                Stream thedatastream = response.GetResponseStream();
                StreamReader reader = new StreamReader(thedatastream);
                data = reader.ReadToEnd();
                reader.Close();
                response.Close();


            }
            catch(Exception ex)
            {
                return false;
            }

            if (data == "true")
                return true;
            else
                return false;
        }

        public int SecurityQuestionId
        {
            get { return seurtiyQuestionId; }
            set { seurtiyQuestionId = value; }  
        }

        public int AccountId
        {
            get { return accountId; }
            set { accountId = value; }
        }

        public String Question
        {
            get { return question; }
            set { question = value; }
        }

        public String QuestionType
        {
            get { return questionType; }
            set { questionType = value; }
        }

        public String Response
        {
            get { return response; }
            set { response = value; }
        }

        public DateTime DateTimeStamp
        {
            get { return dateTimeStamp; }
            set { dateTimeStamp = value; }
        }
    }
}
