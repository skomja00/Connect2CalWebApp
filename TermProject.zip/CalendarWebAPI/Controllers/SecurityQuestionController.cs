﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Utilities;
using CalendarClassLibrary.Model;
using System.Data.SqlClient;
using System.Data;

namespace CalendarCOREWebAPI.Controllers
{
    [Route("api/[controller]")]
    [Produces("application/json")]

    public class SecurityQuestionController : Controller
    {

        DBConnect objDb = new DBConnect();
        SecurityQuestion sec = new SecurityQuestion();

        [HttpPost("AddSecurityQuestion")]
        [Consumes("application/json")]
        public Boolean AddSecurityQuestion([FromQuery] string email, [FromBody] SecurityQuestion theSecurityQuestion)
        {
            

            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = System.Data.CommandType.StoredProcedure;
            objCommand.CommandText = "TP_Account_Security_Questions_SP";

            SqlParameter inputParameter = new SqlParameter("@theAccountId", theSecurityQuestion.AccountId);
            inputParameter.Direction = System.Data.ParameterDirection.Input;
            inputParameter.SqlDbType = System.Data.SqlDbType.Int;
            inputParameter.Size = 4;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@theQuestion", theSecurityQuestion.Question);
            inputParameter.Direction = System.Data.ParameterDirection.Input;
            inputParameter.SqlDbType = System.Data.SqlDbType.VarChar;
            inputParameter.Size = 50;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@theQuestionType", theSecurityQuestion.QuestionType);
            inputParameter.Direction = System.Data.ParameterDirection.Input;
            inputParameter.SqlDbType = System.Data.SqlDbType.VarChar;
            inputParameter.Size = 50;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@theResponse", theSecurityQuestion.Response);
            inputParameter.Direction = System.Data.ParameterDirection.Input;
            inputParameter.SqlDbType = System.Data.SqlDbType.VarChar;
            inputParameter.Size = 50;
            objCommand.Parameters.Add(inputParameter);

            int output = objDb.DoUpdateUsingCmdObj(objCommand);

            if (output > 0)
                return true;
            else
                return false;


        }

        
    }
}
