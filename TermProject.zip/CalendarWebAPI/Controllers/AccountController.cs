﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Utilities;
using System.Data;
using CalendarClassLibrary.Model;

namespace CalendarCOREWebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    
    public class AccountController : Controller
    {
        DBConnect objDb = new DBConnect();

        [HttpPost("AddAccount")]            //Route:    api/Account/AddAccount/
        [Consumes("application/json")]
        public Boolean AddAccount([FromBody] Account theAccount)
        {
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_Account_Insert_SP";

            SqlParameter inputParameter = new SqlParameter("@AccountRoleType", theAccount.AccountRoleType);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 14;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@UserName", theAccount.UserName);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 50;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@UserAddress", theAccount.UserAddress);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@PhoneNumber", theAccount.PhoneNumber);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 50;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@CreatedEmailAddress", theAccount.CreatedEmailAddress);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@ContactEmailAddress", theAccount.ContactEmailAddress);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@Avatar", theAccount.Avatar);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.Int;
            inputParameter.Size = 4;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@AccountPassword", theAccount.AccountPassword);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarBinary;
            // accountPasswordParm.Size = null;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@ResponseCity", "");
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@ResponsePhone", "");
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@ResponseCity", "");
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@DocumentUrl", "");
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);

            inputParameter = new SqlParameter("@DocumentType", "");
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            inputParameter.Size = 254;
            objCommand.Parameters.Add(inputParameter);



            int output = objDb.DoUpdateUsingCmdObj(objCommand);

            if (output > 0)
                return true;
            else
                return false;
        }
    }
}
